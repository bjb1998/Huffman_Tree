import java.util.Arrays;

public class PriorityQueue<T> extends ArrayHeap<T>{

    public PriorityQueue(int[] freq){
        this.arraySize = Arrays.stream(freq).filter(x -> x != 0).toArray().length;
        this.nodes = new HuffmanTreeNode[arraySize];

        for(int i = 0; i < freq.length; i++){
            if(freq[i] != 0)
                this.addArray(new HuffmanTreeNode((char)i, freq[i]));
        }

        this.sortAndMakeList();
    }

    HuffmanTreeNode<T> peek(){ return nodes[0];}

    HuffmanTreeNode<T> poll(){
        HuffmanTreeNode<T> dummy = nodes[0];
        nodes = Arrays.copyOfRange(nodes, 1, nodes.length);
        return dummy;
    }

}
