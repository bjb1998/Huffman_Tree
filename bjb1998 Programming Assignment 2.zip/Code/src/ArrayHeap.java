class ArrayHeap<T> {

    HuffmanTreeNode<T>[] nodes; //Temporary storage until the actual NodeList is made
    int arrayStart = 0;
    int arraySize = 0;

    public ArrayHeap(){}

    protected void addArray(HuffmanTreeNode<T> newNode){
        nodes[arrayStart] = newNode;
        arrayStart++;
    }

    protected void heapify(HuffmanTreeNode<T> newNode) {
        int i = 0;
        HuffmanTreeNode<T>[] result = new HuffmanTreeNode[nodes.length + 1];
        while(i < nodes.length && newNode.compareTo(nodes[i].count) >= 0){
            i++;
        }
        for(int j = 0; j < i; j++)
            result[j] = nodes[j];
        result[i] = newNode;
        for(int j = i + 1; j <= nodes.length; j++)
            result[j] = nodes[j - 1];

        nodes = result;

    }

    protected void print(){
        for(HuffmanTreeNode<T> node : nodes){
            System.out.print("(" + node.nodeChar + ", " + node.count + "), ");
        }
        System.out.println();
    } //TODO: debug method, remove later

    protected void sortAndMakeList(){ //Generic Shell sort w/ basic Knuth Sequence from Assignment 1
        if(nodes == null)
            System.out.println("Error! NodeList already created!");
        int n = nodes.length; //Shell sort
        int gap = 1;
        while (gap < n){ //Create Knuth sequence
            gap = gap * 3 + 1;
        }
        while(gap > 0){
            for (int i = gap; i < n; i += 1){
                HuffmanTreeNode<T> temp = nodes[i];
                int j;
                for (j = i; j >= gap && nodes[j - gap].compareTo(temp.count) > 0; j -= gap)
                    nodes[j] = nodes[j - gap];
                nodes[j] = temp;
            }
            gap = --gap / 3;
        }
        print();
    }

}
